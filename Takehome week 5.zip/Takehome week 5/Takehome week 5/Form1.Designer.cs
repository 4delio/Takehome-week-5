﻿namespace Takehome_week_5
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.animation_time = new System.Windows.Forms.Timer(this.components);
            this.lbl_welcome = new System.Windows.Forms.Label();
            this.logo_cart = new System.Windows.Forms.PictureBox();
            this.pnl_utama = new System.Windows.Forms.Panel();
            this.picture_cart = new System.Windows.Forms.PictureBox();
            this.lbl_blink = new System.Windows.Forms.Label();
            this.btn_remove_category = new System.Windows.Forms.Button();
            this.btn_add_category = new System.Windows.Forms.Button();
            this.tb_nama_category = new System.Windows.Forms.TextBox();
            this.lbl_nama_category = new System.Windows.Forms.Label();
            this.dataview_category = new System.Windows.Forms.DataGridView();
            this.lbl_title_category = new System.Windows.Forms.Label();
            this.btn_remove_product = new System.Windows.Forms.Button();
            this.btn_edit_product = new System.Windows.Forms.Button();
            this.btn_add_product = new System.Windows.Forms.Button();
            this.tb_stock = new System.Windows.Forms.TextBox();
            this.tb_harga = new System.Windows.Forms.TextBox();
            this.cb_category = new System.Windows.Forms.ComboBox();
            this.tb_nama = new System.Windows.Forms.TextBox();
            this.lbl_stock = new System.Windows.Forms.Label();
            this.lbl_harga = new System.Windows.Forms.Label();
            this.lbl_category = new System.Windows.Forms.Label();
            this.lbl_nama = new System.Windows.Forms.Label();
            this.lbl_detail = new System.Windows.Forms.Label();
            this.cb_filter = new System.Windows.Forms.ComboBox();
            this.btn_filter = new System.Windows.Forms.Button();
            this.dataview_product = new System.Windows.Forms.DataGridView();
            this.btn_all = new System.Windows.Forms.Button();
            this.lbl_title_product = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.logo_cart)).BeginInit();
            this.pnl_utama.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.picture_cart)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataview_category)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataview_product)).BeginInit();
            this.SuspendLayout();
            // 
            // animation_time
            // 
            this.animation_time.Enabled = true;
            this.animation_time.Interval = 5;
            this.animation_time.Tick += new System.EventHandler(this.animation_time_Tick);
            // 
            // lbl_welcome
            // 
            this.lbl_welcome.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.lbl_welcome.AutoSize = true;
            this.lbl_welcome.BackColor = System.Drawing.Color.Transparent;
            this.lbl_welcome.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.lbl_welcome.Font = new System.Drawing.Font("Monotype Corsiva", 72F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_welcome.ImageAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.lbl_welcome.Location = new System.Drawing.Point(19, 98);
            this.lbl_welcome.Name = "lbl_welcome";
            this.lbl_welcome.Size = new System.Drawing.Size(1096, 147);
            this.lbl_welcome.TabIndex = 0;
            this.lbl_welcome.Text = "Welcome To Blink Shop";
            this.lbl_welcome.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // logo_cart
            // 
            this.logo_cart.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.logo_cart.BackColor = System.Drawing.Color.IndianRed;
            this.logo_cart.Image = global::Takehome_week_5.Properties.Resources._5a364b752c0633_9984354215135077011803;
            this.logo_cart.Location = new System.Drawing.Point(381, 236);
            this.logo_cart.Name = "logo_cart";
            this.logo_cart.Size = new System.Drawing.Size(340, 340);
            this.logo_cart.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.logo_cart.TabIndex = 2;
            this.logo_cart.TabStop = false;
            // 
            // pnl_utama
            // 
            this.pnl_utama.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.pnl_utama.BackColor = System.Drawing.Color.DarkSalmon;
            this.pnl_utama.Controls.Add(this.picture_cart);
            this.pnl_utama.Controls.Add(this.lbl_blink);
            this.pnl_utama.Controls.Add(this.btn_remove_category);
            this.pnl_utama.Controls.Add(this.btn_add_category);
            this.pnl_utama.Controls.Add(this.tb_nama_category);
            this.pnl_utama.Controls.Add(this.lbl_nama_category);
            this.pnl_utama.Controls.Add(this.dataview_category);
            this.pnl_utama.Controls.Add(this.lbl_title_category);
            this.pnl_utama.Controls.Add(this.btn_remove_product);
            this.pnl_utama.Controls.Add(this.btn_edit_product);
            this.pnl_utama.Controls.Add(this.btn_add_product);
            this.pnl_utama.Controls.Add(this.tb_stock);
            this.pnl_utama.Controls.Add(this.tb_harga);
            this.pnl_utama.Controls.Add(this.cb_category);
            this.pnl_utama.Controls.Add(this.tb_nama);
            this.pnl_utama.Controls.Add(this.lbl_stock);
            this.pnl_utama.Controls.Add(this.lbl_harga);
            this.pnl_utama.Controls.Add(this.lbl_category);
            this.pnl_utama.Controls.Add(this.lbl_nama);
            this.pnl_utama.Controls.Add(this.lbl_detail);
            this.pnl_utama.Controls.Add(this.cb_filter);
            this.pnl_utama.Controls.Add(this.btn_filter);
            this.pnl_utama.Controls.Add(this.dataview_product);
            this.pnl_utama.Controls.Add(this.btn_all);
            this.pnl_utama.Controls.Add(this.lbl_title_product);
            this.pnl_utama.Location = new System.Drawing.Point(12, 12);
            this.pnl_utama.Name = "pnl_utama";
            this.pnl_utama.Size = new System.Drawing.Size(1153, 622);
            this.pnl_utama.TabIndex = 3;
            // 
            // picture_cart
            // 
            this.picture_cart.Image = global::Takehome_week_5.Properties.Resources._5a364b752c0633_9984354215135077011803;
            this.picture_cart.Location = new System.Drawing.Point(649, 484);
            this.picture_cart.Name = "picture_cart";
            this.picture_cart.Size = new System.Drawing.Size(151, 131);
            this.picture_cart.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.picture_cart.TabIndex = 23;
            this.picture_cart.TabStop = false;
            // 
            // lbl_blink
            // 
            this.lbl_blink.AutoSize = true;
            this.lbl_blink.Font = new System.Drawing.Font("Monotype Corsiva", 48F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_blink.Location = new System.Drawing.Point(779, 504);
            this.lbl_blink.Name = "lbl_blink";
            this.lbl_blink.Size = new System.Drawing.Size(367, 97);
            this.lbl_blink.TabIndex = 24;
            this.lbl_blink.Text = "Blink Shop";
            // 
            // btn_remove_category
            // 
            this.btn_remove_category.BackColor = System.Drawing.Color.Tomato;
            this.btn_remove_category.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_remove_category.Location = new System.Drawing.Point(990, 416);
            this.btn_remove_category.Name = "btn_remove_category";
            this.btn_remove_category.Size = new System.Drawing.Size(137, 57);
            this.btn_remove_category.TabIndex = 22;
            this.btn_remove_category.Text = "Remove Category";
            this.btn_remove_category.UseVisualStyleBackColor = false;
            this.btn_remove_category.Click += new System.EventHandler(this.btn_remove_category_Click);
            // 
            // btn_add_category
            // 
            this.btn_add_category.BackColor = System.Drawing.Color.LawnGreen;
            this.btn_add_category.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_add_category.Location = new System.Drawing.Point(847, 414);
            this.btn_add_category.Name = "btn_add_category";
            this.btn_add_category.Size = new System.Drawing.Size(137, 57);
            this.btn_add_category.TabIndex = 21;
            this.btn_add_category.Text = "Add Category";
            this.btn_add_category.UseVisualStyleBackColor = false;
            this.btn_add_category.Click += new System.EventHandler(this.btn_add_category_Click);
            // 
            // tb_nama_category
            // 
            this.tb_nama_category.Location = new System.Drawing.Point(916, 380);
            this.tb_nama_category.Name = "tb_nama_category";
            this.tb_nama_category.Size = new System.Drawing.Size(211, 22);
            this.tb_nama_category.TabIndex = 20;
            // 
            // lbl_nama_category
            // 
            this.lbl_nama_category.AutoSize = true;
            this.lbl_nama_category.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_nama_category.Location = new System.Drawing.Point(843, 378);
            this.lbl_nama_category.Name = "lbl_nama_category";
            this.lbl_nama_category.Size = new System.Drawing.Size(67, 22);
            this.lbl_nama_category.TabIndex = 19;
            this.lbl_nama_category.Text = "Nama :";
            // 
            // dataview_category
            // 
            this.dataview_category.AllowUserToAddRows = false;
            this.dataview_category.AllowUserToDeleteRows = false;
            this.dataview_category.AllowUserToResizeColumns = false;
            this.dataview_category.AllowUserToResizeRows = false;
            this.dataview_category.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataview_category.EditMode = System.Windows.Forms.DataGridViewEditMode.EditProgrammatically;
            this.dataview_category.Location = new System.Drawing.Point(847, 58);
            this.dataview_category.Name = "dataview_category";
            this.dataview_category.RowHeadersWidth = 51;
            this.dataview_category.RowTemplate.Height = 24;
            this.dataview_category.Size = new System.Drawing.Size(280, 305);
            this.dataview_category.TabIndex = 18;
            this.dataview_category.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataview_category_CellClick);
            // 
            // lbl_title_category
            // 
            this.lbl_title_category.AutoSize = true;
            this.lbl_title_category.Font = new System.Drawing.Font("Microsoft Sans Serif", 19.8F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_title_category.Location = new System.Drawing.Point(840, 15);
            this.lbl_title_category.Name = "lbl_title_category";
            this.lbl_title_category.Size = new System.Drawing.Size(158, 38);
            this.lbl_title_category.TabIndex = 17;
            this.lbl_title_category.Text = "Category";
            // 
            // btn_remove_product
            // 
            this.btn_remove_product.BackColor = System.Drawing.Color.Tomato;
            this.btn_remove_product.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_remove_product.Location = new System.Drawing.Point(449, 484);
            this.btn_remove_product.Name = "btn_remove_product";
            this.btn_remove_product.Size = new System.Drawing.Size(83, 96);
            this.btn_remove_product.TabIndex = 16;
            this.btn_remove_product.Text = "Remove Product";
            this.btn_remove_product.UseVisualStyleBackColor = false;
            this.btn_remove_product.Click += new System.EventHandler(this.btn_remove_product_Click);
            // 
            // btn_edit_product
            // 
            this.btn_edit_product.BackColor = System.Drawing.Color.Yellow;
            this.btn_edit_product.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_edit_product.Location = new System.Drawing.Point(369, 485);
            this.btn_edit_product.Name = "btn_edit_product";
            this.btn_edit_product.Size = new System.Drawing.Size(81, 96);
            this.btn_edit_product.TabIndex = 15;
            this.btn_edit_product.Text = "Edit Product";
            this.btn_edit_product.UseVisualStyleBackColor = false;
            this.btn_edit_product.Click += new System.EventHandler(this.btn_edit_product_Click);
            // 
            // btn_add_product
            // 
            this.btn_add_product.BackColor = System.Drawing.Color.LawnGreen;
            this.btn_add_product.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_add_product.Location = new System.Drawing.Point(288, 485);
            this.btn_add_product.Name = "btn_add_product";
            this.btn_add_product.Size = new System.Drawing.Size(81, 96);
            this.btn_add_product.TabIndex = 14;
            this.btn_add_product.Text = "Add Product";
            this.btn_add_product.UseVisualStyleBackColor = false;
            this.btn_add_product.Click += new System.EventHandler(this.btn_add_product_Click);
            // 
            // tb_stock
            // 
            this.tb_stock.Location = new System.Drawing.Point(122, 561);
            this.tb_stock.Name = "tb_stock";
            this.tb_stock.Size = new System.Drawing.Size(139, 22);
            this.tb_stock.TabIndex = 13;
            // 
            // tb_harga
            // 
            this.tb_harga.Location = new System.Drawing.Point(122, 525);
            this.tb_harga.Name = "tb_harga";
            this.tb_harga.Size = new System.Drawing.Size(139, 22);
            this.tb_harga.TabIndex = 12;
            // 
            // cb_category
            // 
            this.cb_category.FormattingEnabled = true;
            this.cb_category.Location = new System.Drawing.Point(121, 485);
            this.cb_category.Name = "cb_category";
            this.cb_category.Size = new System.Drawing.Size(137, 24);
            this.cb_category.TabIndex = 11;
            // 
            // tb_nama
            // 
            this.tb_nama.Location = new System.Drawing.Point(122, 451);
            this.tb_nama.Name = "tb_nama";
            this.tb_nama.Size = new System.Drawing.Size(472, 22);
            this.tb_nama.TabIndex = 10;
            // 
            // lbl_stock
            // 
            this.lbl_stock.AutoSize = true;
            this.lbl_stock.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_stock.Location = new System.Drawing.Point(50, 559);
            this.lbl_stock.Name = "lbl_stock";
            this.lbl_stock.Size = new System.Drawing.Size(65, 22);
            this.lbl_stock.TabIndex = 9;
            this.lbl_stock.Text = "Stock :";
            // 
            // lbl_harga
            // 
            this.lbl_harga.AutoSize = true;
            this.lbl_harga.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_harga.Location = new System.Drawing.Point(47, 523);
            this.lbl_harga.Name = "lbl_harga";
            this.lbl_harga.Size = new System.Drawing.Size(69, 22);
            this.lbl_harga.TabIndex = 8;
            this.lbl_harga.Text = "Harga :";
            // 
            // lbl_category
            // 
            this.lbl_category.AutoSize = true;
            this.lbl_category.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_category.Location = new System.Drawing.Point(24, 488);
            this.lbl_category.Name = "lbl_category";
            this.lbl_category.Size = new System.Drawing.Size(93, 22);
            this.lbl_category.TabIndex = 7;
            this.lbl_category.Text = "Category :";
            // 
            // lbl_nama
            // 
            this.lbl_nama.AutoSize = true;
            this.lbl_nama.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_nama.Location = new System.Drawing.Point(49, 449);
            this.lbl_nama.Name = "lbl_nama";
            this.lbl_nama.Size = new System.Drawing.Size(67, 22);
            this.lbl_nama.TabIndex = 6;
            this.lbl_nama.Text = "Nama :";
            // 
            // lbl_detail
            // 
            this.lbl_detail.AutoSize = true;
            this.lbl_detail.Font = new System.Drawing.Font("Microsoft Sans Serif", 19.8F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_detail.Location = new System.Drawing.Point(45, 389);
            this.lbl_detail.Name = "lbl_detail";
            this.lbl_detail.Size = new System.Drawing.Size(124, 38);
            this.lbl_detail.TabIndex = 5;
            this.lbl_detail.Text = "Details";
            // 
            // cb_filter
            // 
            this.cb_filter.Enabled = false;
            this.cb_filter.FormattingEnabled = true;
            this.cb_filter.Location = new System.Drawing.Point(642, 28);
            this.cb_filter.Name = "cb_filter";
            this.cb_filter.Size = new System.Drawing.Size(145, 24);
            this.cb_filter.TabIndex = 4;
            this.cb_filter.SelectedIndexChanged += new System.EventHandler(this.cb_filter_SelectedIndexChanged);
            // 
            // btn_filter
            // 
            this.btn_filter.Location = new System.Drawing.Point(582, 30);
            this.btn_filter.Name = "btn_filter";
            this.btn_filter.Size = new System.Drawing.Size(59, 23);
            this.btn_filter.TabIndex = 3;
            this.btn_filter.Text = "Filter";
            this.btn_filter.UseVisualStyleBackColor = true;
            this.btn_filter.Click += new System.EventHandler(this.btn_filter_Click);
            // 
            // dataview_product
            // 
            this.dataview_product.AllowUserToAddRows = false;
            this.dataview_product.AllowUserToDeleteRows = false;
            this.dataview_product.AllowUserToResizeColumns = false;
            this.dataview_product.AllowUserToResizeRows = false;
            this.dataview_product.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataview_product.EditMode = System.Windows.Forms.DataGridViewEditMode.EditProgrammatically;
            this.dataview_product.Location = new System.Drawing.Point(49, 58);
            this.dataview_product.Name = "dataview_product";
            this.dataview_product.RowHeadersWidth = 51;
            this.dataview_product.RowTemplate.Height = 24;
            this.dataview_product.Size = new System.Drawing.Size(738, 305);
            this.dataview_product.TabIndex = 2;
            this.dataview_product.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataview_product_CellClick);
            // 
            // btn_all
            // 
            this.btn_all.Location = new System.Drawing.Point(544, 30);
            this.btn_all.Name = "btn_all";
            this.btn_all.Size = new System.Drawing.Size(37, 23);
            this.btn_all.TabIndex = 1;
            this.btn_all.Text = "All";
            this.btn_all.UseVisualStyleBackColor = true;
            this.btn_all.Click += new System.EventHandler(this.btn_all_Click);
            // 
            // lbl_title_product
            // 
            this.lbl_title_product.AutoSize = true;
            this.lbl_title_product.Font = new System.Drawing.Font("Microsoft Sans Serif", 19.8F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_title_product.Location = new System.Drawing.Point(42, 14);
            this.lbl_title_product.Name = "lbl_title_product";
            this.lbl_title_product.Size = new System.Drawing.Size(137, 38);
            this.lbl_title_product.TabIndex = 0;
            this.lbl_title_product.Text = "Product";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.BackColor = System.Drawing.Color.IndianRed;
            this.ClientSize = new System.Drawing.Size(1177, 646);
            this.Controls.Add(this.pnl_utama);
            this.Controls.Add(this.lbl_welcome);
            this.Controls.Add(this.logo_cart);
            this.Name = "Form1";
            this.Text = "Adelio Surya Putra Pratama/0706022310039";
            this.Load += new System.EventHandler(this.Form1_Load);
            ((System.ComponentModel.ISupportInitialize)(this.logo_cart)).EndInit();
            this.pnl_utama.ResumeLayout(false);
            this.pnl_utama.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.picture_cart)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataview_category)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataview_product)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.Timer animation_time;
        private System.Windows.Forms.Label lbl_welcome;
        private System.Windows.Forms.PictureBox logo_cart;
        private System.Windows.Forms.Panel pnl_utama;
        private System.Windows.Forms.Label lbl_title_product;
        private System.Windows.Forms.Label lbl_detail;
        private System.Windows.Forms.ComboBox cb_filter;
        private System.Windows.Forms.Button btn_filter;
        private System.Windows.Forms.DataGridView dataview_product;
        private System.Windows.Forms.Button btn_all;
        private System.Windows.Forms.Label lbl_category;
        private System.Windows.Forms.Label lbl_nama;
        private System.Windows.Forms.TextBox tb_stock;
        private System.Windows.Forms.TextBox tb_harga;
        private System.Windows.Forms.ComboBox cb_category;
        private System.Windows.Forms.TextBox tb_nama;
        private System.Windows.Forms.Label lbl_stock;
        private System.Windows.Forms.Label lbl_harga;
        private System.Windows.Forms.Button btn_add_product;
        private System.Windows.Forms.Label lbl_title_category;
        private System.Windows.Forms.Button btn_remove_product;
        private System.Windows.Forms.Button btn_edit_product;
        private System.Windows.Forms.DataGridView dataview_category;
        private System.Windows.Forms.Label lbl_blink;
        private System.Windows.Forms.PictureBox picture_cart;
        private System.Windows.Forms.Button btn_remove_category;
        private System.Windows.Forms.Button btn_add_category;
        private System.Windows.Forms.TextBox tb_nama_category;
        private System.Windows.Forms.Label lbl_nama_category;
    }
}

