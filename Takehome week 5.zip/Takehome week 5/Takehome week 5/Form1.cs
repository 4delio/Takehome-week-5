﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Takehome_week_5
{
    public partial class Form1 : Form
    {
        DataTable dt_product = new DataTable();
        DataTable dt_category = new DataTable();
        DataTable dt_filter_product = new DataTable();
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            lbl_welcome.Top = 90;
            logo_cart.Left = -20;
            pnl_utama.Visible = false;
            dt_product.Columns.Add("ID Product");
            dt_product.Columns.Add("Nama Product");
            dt_product.Columns.Add("Harga");
            dt_product.Columns.Add("Stock");
            dt_product.Columns.Add("ID Category");
            dt_product.Rows.Add("J001","Jas Hitam","100.000","10","C1");
            dt_product.Rows.Add("T001", "T-Shirt Black Pink", "70.000", "20", "C2");
            dt_product.Rows.Add("T002", "T-Shirt Obsessive", "75.000", "16", "C2");
            dt_product.Rows.Add("R001", "Rok Mini", "82.000", "26", "C3");
            dt_product.Rows.Add("J002", "Jeans Biru", "90.000", "5", "C4");
            dt_product.Rows.Add("C001", "Celana Pendek Coklat", "60.000", "11", "C4");
            dt_product.Rows.Add("C002", "Cawat Blink-blink", "1.000.000", "1", "C5");
            dt_product.Rows.Add("R002", "Rocca Shirt", "50.000", "8", "C2");
            dt_category.Columns.Add("ID Category");
            dt_category.Columns.Add("Nama Category");
            dt_category.Rows.Add("C1", "Jas");
            dt_category.Rows.Add("C2", "T-Shirt");
            dt_category.Rows.Add("C3", "Rok");
            dt_category.Rows.Add("C4", "Celana");
            dt_category.Rows.Add("C5", "Cawat");
            dt_filter_product = dt_product.Copy();
            dataview_product.DataSource = dt_filter_product;
            dataview_category.DataSource = dt_category;
            for (int i = 0; i < dt_category.Rows.Count; i++)
            {
                cb_filter.Items.Add(dt_category.Rows[i][1]);
                cb_category.Items.Add(dt_category.Rows[i][1]);
            }
            dataview_product.ClearSelection();
            dataview_category.ClearSelection();
        }

        private void animation_time_Tick(object sender, EventArgs e)
        {
            if (logo_cart.Left < 1000)
            {
                logo_cart.Left += 5;
            }
            else
            {
                pnl_utama.Visible = true;
                logo_cart.Visible = false;
            }
            for (int i = 0; i <dt_product.Rows.Count; i++)
            {
                if (dt_product.Rows[i][3].ToString() =="0")
                {
                    dt_filter_product.Rows.RemoveAt(i);
                    dt_product.Rows.RemoveAt(i);
                }
            }
        }

        private void btn_all_Click(object sender, EventArgs e)
        {
            cb_filter.Text = string.Empty;
            tb_harga.Text = string.Empty;
            tb_nama.Text = string.Empty;
            tb_stock.Text = string.Empty;
            cb_category.Text = string.Empty;
            tb_nama_category.Text = string.Empty;
            for (int i = dataview_product.Rows.Count - 1; i >= 0; i--)
            {
                dataview_product.Rows.RemoveAt(i);
            }
            for (int i = 0; i < dt_product.Rows.Count; i++)
            {
                dt_filter_product.Rows.Add(dt_product.Rows[i][0].ToString(), dt_product.Rows[i][1].ToString(), dt_product.Rows[i][2].ToString(), dt_product.Rows[i][3].ToString(), dt_product.Rows[i][4].ToString());
            }
        }

        private void btn_filter_Click(object sender, EventArgs e)
        {
          cb_filter.Enabled = true;
        }

        private void dataview_product_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            tb_nama.Text = dataview_product.CurrentRow.Cells[1].Value.ToString();
            tb_harga.Text = dataview_product.CurrentRow.Cells[2].Value.ToString();
            tb_stock.Text = dataview_product.CurrentRow.Cells[3].Value.ToString();
            cb_category.Text = dataview_product.CurrentRow.Cells[4].Value.ToString();
            for (int i = 0; i < dt_category.Rows.Count; i++)
            {
                if (cb_category.Text == dt_category.Rows[i][0].ToString())
                {
                    cb_category.Text = dt_category.Rows[i][1].ToString();
                }
            }
        }

        private void btn_add_product_Click(object sender, EventArgs e)
        {
            string angka = "1234567890.";
            if (tb_nama.Text.Length != 0 || tb_harga.Text.Length !=0 || tb_stock.Text.Length != 0 || cb_category.Text.Length != 0)
            {
                int ceks = 0;
                foreach(char a in tb_harga.Text)
                {
                    foreach(char b in angka)
                    {
                        if (b == a)
                        {
                            ceks ++;
                        }
                    }
                }
                if (ceks != tb_harga.Text.Length)
                {
                    MessageBox.Show("Hanya boleh menggunakan angka");
                }
                else
                {
                    ceks = 0;
                    foreach (char a in tb_stock.Text)
                    {
                        foreach (char b in angka)
                        {
                            if (b == a)
                            {
                                ceks++;
                            }
                        }
                    }
                    if (ceks != tb_stock.Text.Length)
                    {
                        MessageBox.Show("Hanya boleh menggunakan angka");
                    }
                    else
                    {
                        for (int i = dataview_product.Rows.Count - 1; i >= 0; i--)
                        {
                            dataview_product.Rows.RemoveAt(i);
                        }
                        for (int i = 0; i < dt_product.Rows.Count; i++)
                        {
                            dt_filter_product.Rows.Add(dt_product.Rows[i][0].ToString(), dt_product.Rows[i][1].ToString(), dt_product.Rows[i][2].ToString(), dt_product.Rows[i][3].ToString(), dt_product.Rows[i][4].ToString());
                        }
                        int cek = 1;
                        int cek2 = 0;
                        int cek3 = 0;
                        for (int i = 0; i < dt_product.Rows.Count; i++)
                        {
                            if (tb_nama.Text[0].ToString().ToUpper() == dt_product.Rows[i][0].ToString().Substring(0, 1).ToUpper())
                            {
                                if (cek == 9)
                                {
                                    cek = 0;
                                    if (cek2 == 9)
                                    {
                                        cek2 = 0;
                                        cek3++;
                                    }
                                    else
                                    {
                                        cek2++;
                                    }
                                }
                                else
                                {
                                    cek++;
                                }
                                if(tb_nama.Text[0].ToString().ToUpper()+cek3+cek2+cek== dt_product.Rows[i][0].ToString())
                                {
                                    cek++;
                                    if (cek == 9)
                                    {
                                        cek = 0;
                                        if (cek2 == 9)
                                        {
                                            cek2 = 0;
                                            cek3++;
                                        }
                                        else
                                        {
                                            cek2++;
                                        }
                                    }
                                }
                            }
                        }
                        string category = "";
                        for (int i = 0; i < dt_category.Rows.Count; i++)
                        {
                            if (cb_category.Text == dt_category.Rows[i][1].ToString())
                            {
                                category = dt_category.Rows[i][0].ToString();
                            }
                        }
                        long harga = Convert.ToInt64(tb_harga.Text.Replace(".", ""));
                        string format = harga.ToString("N0");
                        dt_product.Rows.Add(tb_nama.Text[0].ToString().ToUpper() + cek3 + cek2 + cek, tb_nama.Text, format, tb_stock.Text, category);
                        dt_filter_product.Rows.Add(tb_nama.Text[0].ToString().ToUpper() + cek3 + cek2 + cek, tb_nama.Text, format, tb_stock.Text, category);
                        tb_harga.Text = string.Empty;
                        tb_nama.Text = string.Empty;
                        tb_stock.Text = string.Empty;
                        cb_category.Text = string.Empty;
                    }
                }
            }
            else
            {
                MessageBox.Show("Input yang lengkap ya");
            }
        }

        private void dataview_category_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            tb_nama_category.Text = dataview_category.CurrentRow.Cells[1].Value.ToString();
        }

        private void btn_edit_product_Click(object sender, EventArgs e)
        {
            string angka = "1234567890.";
            if (tb_nama.Text.Length != 0 || tb_harga.Text.Length != 0 || tb_stock.Text.Length != 0 || cb_category.Text.Length != 0)
            {
                int ceks = 0;
                foreach (char a in tb_harga.Text)
                {
                    foreach (char b in angka)
                    {
                        if (b == a)
                        {
                            ceks++;
                        }
                    }
                }
                if (ceks != tb_harga.Text.Length)
                {
                    MessageBox.Show("Input yang lengkap ya");
                }
                else
                {
                    ceks = 0;
                    foreach (char a in tb_stock.Text)
                    {
                        foreach (char b in angka)
                        {
                            if (b == a)
                            {
                                ceks++;
                            }
                        }
                    }
                    if (ceks != tb_stock.Text.Length)
                    {
                        MessageBox.Show("Input yang lengkap ya");
                    }
                    else
                    {
                        string selectedid = dataview_product.CurrentRow.Cells[0].Value.ToString();
                        for (int i = dataview_product.Rows.Count - 1; i >= 0; i--)
                        {
                            dataview_product.Rows.RemoveAt(i);
                        }
                        for (int i = 0; i < dt_product.Rows.Count; i++)
                        {
                            dt_filter_product.Rows.Add(dt_product.Rows[i][0].ToString(), dt_product.Rows[i][1].ToString(), dt_product.Rows[i][2].ToString(), dt_product.Rows[i][3].ToString(), dt_product.Rows[i][4].ToString());
                        }
                        for (int i = 0; i < dt_category.Rows.Count; i++)
                        {
                            if (cb_category.Text == dt_category.Rows[i][1].ToString())
                            {
                                cb_category.Text = dt_category.Rows[i][0].ToString();
                            }
                        }
                        long harga = Convert.ToInt64(tb_harga.Text.Replace(".", ""));
                        string format = harga.ToString("N0");
                        for (int i = 0; i < dt_filter_product.Rows.Count; i++)
                        {
                            if (dt_filter_product.Rows[i][0].ToString() == selectedid)
                            {
                                dt_filter_product.Rows[i][1] = tb_nama.Text;
                                dt_filter_product.Rows[i][2] = format;
                                dt_filter_product.Rows[i][3] = tb_stock.Text;
                                dt_filter_product.Rows[i][4] = cb_category.Text;
                                dt_product.Rows[i][1] = tb_nama.Text;
                                dt_product.Rows[i][2] = format;
                                dt_product.Rows[i][3] = tb_stock.Text;
                                dt_product.Rows[i][4] = cb_category.Text;
                            }
                        }
                        tb_harga.Text = string.Empty;
                        tb_nama.Text = string.Empty;
                        tb_stock.Text = string.Empty;
                        cb_category.Text = string.Empty;
                        cb_filter.Text = string.Empty;
                        dataview_product.ClearSelection();
                    }
                }
            }
            else
            {
                MessageBox.Show("Input yang lengkap ya");
            }
        }

        private void btn_remove_product_Click(object sender, EventArgs e)
        {
            if (tb_nama.Text.Length != 0 || tb_harga.Text.Length != 0 || tb_stock.Text.Length != 0 || cb_category.Text.Length != 0)
            {
                string selectedid = dataview_product.CurrentRow.Cells[0].Value.ToString();
                if (dataview_product.Rows.Count != dt_product.Rows.Count)
                {
                    for (int i = dataview_product.Rows.Count - 1; i >= 0; i--)
                    {
                        dataview_product.Rows.RemoveAt(i);
                    }
                    for (int i = 0; i < dt_product.Rows.Count; i++)
                    {
                        dt_filter_product.Rows.Add(dt_product.Rows[i][0].ToString(), dt_product.Rows[i][1].ToString(), dt_product.Rows[i][2].ToString(), dt_product.Rows[i][3].ToString(), dt_product.Rows[i][4].ToString());
                    }
                }
                for (int i = 0; i < dt_filter_product.Rows.Count; i++)
                {
                    if (dt_filter_product.Rows[i][0].ToString() == selectedid)
                    {
                        dt_filter_product.Rows.RemoveAt(i);
                        dt_product.Rows.RemoveAt(i);
                    }
                }
                tb_harga.Text = string.Empty;
                tb_nama.Text = string.Empty;
                tb_stock.Text = string.Empty;
                cb_category.Text = string.Empty;
                cb_filter.Text = string.Empty;
                dataview_product.ClearSelection();
            }
            else
            {
                MessageBox.Show("Pilih barang terlebih dahulu");
            }
        }

        private void btn_add_category_Click(object sender, EventArgs e)
        {
            if (tb_nama_category.Text.Length > 0)
            {
                bool ada = false;
                for (int i = 0; i < dataview_category.Rows.Count; i++)
                {
                    if (dt_category.Rows[i][1].ToString() == tb_nama_category.Text)
                    {
                        ada = true;
                        MessageBox.Show("Category sudah ada");
                    }
                }
                if (ada == false)
                {
                    int jumlah = dt_category.Rows.Count-1;
                    int urutan = Convert.ToInt32(dt_category.Rows[jumlah][0].ToString().Substring(1,1));
                    dt_category.Rows.Add("C" + (urutan+1), tb_nama_category.Text);
                    cb_category.Items.Add(tb_nama_category.Text);
                    cb_filter.Items.Add(tb_nama_category.Text);
                    tb_nama_category.Text = string.Empty;
                    dataview_category.ClearSelection();
                }
            }
            else
            {
                MessageBox.Show("Input yang lengkap ya");
            }
        }

        private void btn_remove_category_Click(object sender, EventArgs e)
        {
            string urutan = "";
            int urut = dataview_category.Rows.Count;
            if (tb_nama_category.Text.Length > 0)
            {
                for (int i = 0; i < urut; i++)
                {
                    if (dt_category.Rows[i][1].ToString() == tb_nama_category.Text)
                    {
                        urutan = dt_category.Rows[i][0].ToString();
                        dt_category.Rows.RemoveAt(i);
                        cb_category.Items.RemoveAt(i);
                        cb_filter.Items.RemoveAt(i);
                        dataview_category.ClearSelection();
                        break;
                    }
                }
                for (int j = 0; j < dt_product.Rows.Count; j++)
                {
                    if (dt_product.Rows[j][4].ToString() == urutan)
                    {
                        dt_filter_product.Rows.RemoveAt(j);
                        dt_product.Rows.RemoveAt(j);
                        j = -1;
                    }
                }
                tb_nama_category.Text = string.Empty;
                dataview_category.ClearSelection();
            }
            else
            {
                MessageBox.Show("Pilih Category terlebih dahulu");
            }
        }

        private void cb_filter_SelectedIndexChanged(object sender, EventArgs e)
        {
            tb_harga.Text = string.Empty;
            tb_nama.Text = string.Empty;
            tb_stock.Text = string.Empty;
            cb_category.Text = string.Empty;
            tb_nama_category.Text = string.Empty;
            string pilih = "";
            if (cb_filter.Text.Length > 0)
            {
                for (int i = dataview_product.Rows.Count - 1; i >= 0; i--)
                {
                    dataview_product.Rows.RemoveAt(i);
                }
                for (int i = 0; i < dt_product.Rows.Count; i++)
                {
                    dt_filter_product.Rows.Add(dt_product.Rows[i][0].ToString(), dt_product.Rows[i][1].ToString(), dt_product.Rows[i][2].ToString(), dt_product.Rows[i][3].ToString(), dt_product.Rows[i][4].ToString());
                }
                for (int i = 0; i < dt_category.Rows.Count; i++)
                {
                    if (cb_filter.Text == dt_category.Rows[i][1].ToString())
                    {
                        pilih = dt_category.Rows[i][0].ToString();
                    }
                }
                for (int i = dt_filter_product.Rows.Count - 1; i >= 0; i--)
                {
                    if (dt_product.Rows[i][4].ToString() != pilih)
                    {
                        dt_filter_product.Rows.RemoveAt(i);
                    }
                }
            }
        }
    }
}
